
package newclass;

import java.util.Scanner;


public class NewClass {

   
    public static void main(String[] args) {
        int id;
        char option;
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Enter an ID: ");
        id = sc.nextInt();
        
        SalesManager x = new SalesManager(id);
        System.out.println("Good Day " + x.getName());
        
        for(;;){
            System.out.println("[T]ake Order \t [A]uthorized Order \t [E]xit");
            System.out.print("Select Operation: ");
            option = sc.next() .charAt(0);
            if(option=='T' || option=='t'){
                x.takeOrder();
            }
            else if(option=='A' || option=='a'){
                x.authorize();
            }
            else if(option=='E' || option=='e'){
                System.exit(0);
            }
            else{
                System.out.print("Invalid Option");
            }
        }
               
                
    }
    
}
