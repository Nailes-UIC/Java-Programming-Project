
package newclass;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;


public class SalesManager extends SalesPerson implements manage {
    
    private Scanner sc = new Scanner(System.in);
    private String sqlStatement;

     public SalesManager(int id) {
        super(id);
    }

    @Override
    public void authorize() {
        int orderID;
        System.out.println("Enter Order ID to authorize order transaction: ");
        orderID = sc.nextInt();
        
        sqlStatement = "Update orders set status=? where orderID=?";
        try {
            PreparedStatement sqlQuery = DbaseConnection.conn.prepareStatement(sqlStatement);
            sqlQuery.setInt(1, 1);
            
            sqlQuery.setInt(2, orderID);
            sqlQuery.executeUpdate();
            System.out.println("Order has been authorized.");
        } catch (SQLException ex) {
            System.out.println("Error in Updating");
        }
    }
}


