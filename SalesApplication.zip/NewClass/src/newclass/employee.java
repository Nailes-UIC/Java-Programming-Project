
package newclass;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class employee {
    int id;
    private String name;
    private String sqlStatement;

    public employee(int id) {
        this.id = id;
    }

    public String getName() {
        
        DbaseConnection.connection();
        sqlStatement = "Select Name from employee where ID = '"+id+"'";

        try {
            PreparedStatement sqlQuery = DbaseConnection.conn.prepareStatement(sqlStatement);
            ResultSet result = sqlQuery.executeQuery();
            while (result.next()) {
                name = result.getString("Name");
            }
        } catch (SQLException ex) {
            System.out.println("Error in retrieving");
        }

        return name;
    }
}
