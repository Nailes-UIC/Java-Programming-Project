package newclass;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class HR {
    private Scanner sc = new Scanner(System.in);


    public void addEmployee() {
        String name;
        int id;
        double salary;
        double commission;
        String position;
        
        
        System.out.print("Enter Employee ID: ");
        id = sc.nextInt();
        sc.nextLine();  
        System.out.print("Enter Employee Name: ");
        name = sc.nextLine();
        System.out.print("Enter Employee Position: ");
        position = sc.nextLine(); 
        System.out.print("Enter Employee Salary: ");
        salary = sc.nextDouble();
        System.out.print("Enter Employee Commission: ");
        commission = sc.nextDouble(); 
        
        
        String sqlStatement = "INSERT INTO employee (ID, Name, Position, Salary, Commission) VALUES (?, ?, ?, ?, ?)";
        
        DbaseConnection.connection();
        
        try (PreparedStatement sqlQuery = DbaseConnection.conn.prepareStatement(sqlStatement)) {
          
            sqlQuery.setInt(1, id);
            sqlQuery.setString(2, name);
            sqlQuery.setString(3, position);  
            sqlQuery.setDouble(4, salary);
            sqlQuery.setDouble(5, commission);  
            
          
            int rowsAffected = sqlQuery.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Employee added successfully.");
            }
        } catch (SQLException ex) {
            System.out.println("Error adding employee: " + ex.getMessage());
        } finally {
            DbaseConnection.closeConnection();
        }
    }


    public static void main(String[] args) {
        HR hr = new HR(); 
        hr.addEmployee();  
    }
}
