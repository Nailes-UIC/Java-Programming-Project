package newclass;

public interface manage {
    void authorize();
}

