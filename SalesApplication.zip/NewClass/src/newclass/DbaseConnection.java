package newclass;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbaseConnection {
    public static Connection conn;


    private static final String URL = "jdbc:mysql://localhost:3306/furniture?zeroDateTimeBehavior=CONVERT_TO_NULL"; 
    private static final String USER = "root";
    private static final String PASSWORD = ""; 

    public static void connection() {
        if (conn == null) {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                conn = DriverManager.getConnection(URL, USER, PASSWORD);
                System.out.println("Database connection established.");
            } catch (ClassNotFoundException ex) {
                System.out.println("JDBC Driver not found: " + ex.getMessage());
            } catch (SQLException ex) {
                System.out.println("Error connecting to the database: " + ex.getMessage());
            }
        }
    }
    
    public static void closeConnection() {
        if (conn != null) {
            try {
                conn.close();
                conn = null;
                System.out.println("Database connection closed.");
            } catch (SQLException ex) {
                System.out.println("Error closing the database connection: " + ex.getMessage());
            }
        }
    }
}
