
package newclass;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class SalesPerson extends employee {
    private String sqlStatement;
    Scanner sc = new Scanner(System.in);

    public SalesPerson(int id) {
        super(id);
    }

  public void takeOrder() {
    double price = 0.0, cost = 0.0, commissionRate = 0.10, commissionAmount = 0.0;
    int furID, quantity, availableStock, orderID;
    int orderStatus = 0; 

    System.out.print("Enter furniture ID to order: ");
    furID = sc.nextInt();
    System.out.print("Enter the quantity: ");
    quantity = sc.nextInt();

    DbaseConnection.connection();
    
    sqlStatement = "SELECT Price, Quantity FROM furnituresample WHERE furID = ?"; 

    try (PreparedStatement sqlquery = DbaseConnection.conn.prepareStatement(sqlStatement)) {
        sqlquery.setInt(1, furID);
        ResultSet result = sqlquery.executeQuery();

        if (!result.next()) {
            System.out.println("Furniture ID does not exist");
            return;
        }

        price = result.getDouble("Price");
        availableStock = result.getInt("Quantity"); 

        if (quantity > availableStock) {
            System.out.println("Insufficient stocks available.");
            return;
        }

        cost = quantity * price;
        commissionAmount = cost * commissionRate;
        System.out.printf("Total cost is: %.2f%n", cost);
        System.out.printf("Commission earned is: %.2f%n", commissionAmount);

        
        sqlStatement = "INSERT INTO orders (furnitureID, quantity, totalCost, status) VALUES (?, ?, ?, ?)";
        try (PreparedStatement insertOrder = DbaseConnection.conn.prepareStatement(sqlStatement, PreparedStatement.RETURN_GENERATED_KEYS)) {
            insertOrder.setInt(1, furID);
            insertOrder.setInt(2, quantity);
            insertOrder.setDouble(3, cost);
            insertOrder.setInt(4, orderStatus);  

          
            int affectedRows = insertOrder.executeUpdate();

           
            if (affectedRows == 0) {
                throw new SQLException("Creating order failed, no rows affected.");
            }

            
            try (ResultSet generatedKeys = insertOrder.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    orderID = generatedKeys.getInt(1);
                } else {
                    throw new SQLException("Creating order failed, no ID obtained.");
                }
            }
        }

       
        sqlStatement = "INSERT INTO commtransaction (orderID, EmpID, totalComm) VALUES (?, ?, ?)";
        try (PreparedStatement insertCommission = DbaseConnection.conn.prepareStatement(sqlStatement)) {
            insertCommission.setInt(1, orderID);
            insertCommission.setInt(2, this.id);
            insertCommission.setDouble(3, commissionAmount);
            insertCommission.executeUpdate();
        }

        System.out.println("Order and commission have been saved");

    } catch (SQLException ex) {
        System.out.println("Error in processing the order: " + ex.getMessage());
    } finally {
        DbaseConnection.closeConnection();
    }
}
}
    

