public class Truck extends LandVehicle {
    private double loadCapacity;
    private boolean hasTrailer;
    
    public Truck(String vehicleType, double maxSpeed, double fuelCapacity, boolean hasTires, int numWheels, double loadCapacity, boolean hasTrailer) {
        super(vehicleType, maxSpeed, fuelCapacity, hasTires, numWheels); 
        this.loadCapacity = loadCapacity;
        this.hasTrailer = hasTrailer;
    }
    
    public boolean hasTrailer() {
        return hasTrailer;
    }
    
    @Override
    public void display(){
        System.out.println("");
        super.display();
        System.out.println("The Load Capacity is: " + loadCapacity + " lbs");
        System.out.println("Has Trailer: " + hasTrailer);
        
    }
    
}

