public class Airplane extends AirVehicle {
    private int numEngines;
    private boolean hasCockpit;
    
    public Airplane(String vehicleType, double maxSpeed, double fuelCapacity, boolean canFly, boolean hasWings, boolean hasCockpit, int numEngines) {
        super(vehicleType, maxSpeed, fuelCapacity, hasWings, canFly);  // Call the constructor of Vehicle
        this.numEngines = numEngines;
        this.hasCockpit = hasCockpit;
    }
    
    public boolean hasCockpit() {
        return hasCockpit;
    }
    
    @Override
    public void display() {
        super.display();  // Call the method from LandVehicle to display common info
        System.out.println("Number of Engines: " + numEngines);
        System.out.println("Has Cockpit: " + hasCockpit);
    }
}
