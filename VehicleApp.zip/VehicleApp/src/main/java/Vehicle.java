public abstract class Vehicle {

    private double maxSpeed, fuelCapacity;
    private String vehicleType;
    

    // Constructor
    public Vehicle(String vehicleType, double maxSpeed, double fuelCapacity) {
        this.vehicleType = vehicleType;
        this.maxSpeed = maxSpeed;
        this.fuelCapacity = fuelCapacity;
    }
    
    public void display() {
        System.out.println("Vehicle Type: " + vehicleType);
        System.out.println("Max Speed: " + maxSpeed + " km/h");
        System.out.println("Fuel Capacity: " + fuelCapacity + " liters");
    }
    
}
