public class Car extends LandVehicle {
    private int numDoors;
    private boolean hasTrunk;
    
    public Car(String vehicleType, double maxSpeed, double fuelCapacity, boolean hasTires, int numWheels, boolean hasTrunk, int numDoors) {
        super(vehicleType, maxSpeed, fuelCapacity, hasTires, numWheels);  // Call the constructor of Vehicle
        this.numDoors = numDoors;
        this.hasTrunk = hasTrunk;
    }
    
    public boolean hasTrunk() {
        return hasTrunk;
    }
    
    @Override
    public void display() {
        super.display();  // Call the method from LandVehicle to display common info
        System.out.println("Number of Doors: " + numDoors);
        System.out.println("Has Trunk: " + hasTrunk);
    }
}
