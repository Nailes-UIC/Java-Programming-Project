public class Motorcycle extends LandVehicle {
    private boolean hasHandlebars, isTwoWheeled;   // Attribute to indicate if the motorcycle is two-wheeled

    // Constructor for Motorcycle
    public Motorcycle(String vehicleType, double maxSpeed, double fuelCapacity, boolean hasTires, int numWheels, boolean hasHandlebars, boolean isTwoWheeled) {
        super(vehicleType, maxSpeed, fuelCapacity, hasTires, numWheels);
        this.hasHandlebars = hasHandlebars;
        this.isTwoWheeled = isTwoWheeled;
    }

    // Method to check if the motorcycle has handlebars
    public boolean hasHandlebars() {
        return hasHandlebars;
    }

    // Method to check if the motorcycle is two-wheeled
    public boolean isTwoWheeled() {
        return isTwoWheeled;
    }

    @Override
    public void display() {
        super.display();  // Call the method from LandVehicle to display common info
        System.out.println("Has Handlebars: " + hasHandlebars);
        System.out.println("Is Two-Wheeled: " + isTwoWheeled);
    }
}
