public class WaterVehicle extends Vehicle {
    private boolean isSeaworthy;
    private boolean hasHull;;
    
    // Constructor for LandVehicle
    public WaterVehicle(String vehicleType, double maxSpeed, double fuelCapacity,boolean isSeaworthy, boolean hasHull) {
        super(vehicleType, maxSpeed, fuelCapacity);  // Call the constructor of the Vehicle class
        this.isSeaworthy = isSeaworthy;
        this.hasHull = hasHull;
    }

    // Method to check if the vehicle has tires
    public boolean isSeaworthy() {
        return isSeaworthy;
    }
    public boolean hasHull() {
        return hasHull;
    }

    public void display() {
        super.display();
        System.out.println("Is Sea Worthy: " + isSeaworthy);
        System.out.println("Has Huull: " + hasHull);
    }
}

