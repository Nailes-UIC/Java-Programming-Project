public abstract class LandVehicle extends Vehicle {
    private int numWheels;
    private boolean hasTires;;
    
    // Constructor for LandVehicle
    public LandVehicle(String vehicleType, double maxSpeed, double fuelCapacity,boolean hasTires, int numWheels) {
        super(vehicleType, maxSpeed, fuelCapacity);  // Call the constructor of the Vehicle class
        this.numWheels = numWheels;
        this.hasTires = hasTires;
    }

    // Method to check if the vehicle has tires
    public boolean hasTires() {
        return hasTires;
    }

    public void display() {
        super.display();
        System.out.println("Number of Wheels: " + numWheels);
        System.out.println("Has Tires: " + hasTires);
    }
}
