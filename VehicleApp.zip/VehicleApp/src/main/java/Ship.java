public class Ship extends WaterVehicle {
    private boolean displacement;
    private boolean hasCargoHold;
    
    public Ship(String vehicleType, double maxSpeed, double fuelCapacity, boolean canFly, boolean hasWings, boolean displacement, boolean hasCargoHold) {
        super(vehicleType, maxSpeed, fuelCapacity, hasWings, canFly);  // Call the constructor of Vehicle
        this.displacement = displacement;
        this.hasCargoHold = hasCargoHold;
    }
    
    public boolean displacement() {
        return displacement;
    }
    
    public boolean hasKhasCargoHoldeel() {
        return hasCargoHold;
    }
    
    @Override
    public void display() {
        super.display();  // Call the method from LandVehicle to display common info
        System.out.println("Displacement: " + displacement);
        System.out.println("Has Cargo Hold: " + hasCargoHold);
    }
}
