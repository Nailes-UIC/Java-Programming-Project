import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        int choice;
        
        
        System.out.println("Choose kind of vehicle: ");
        System.out.println("1. Land Vehicle");
        System.out.println("2. Air Vehicle");
        System.out.println("3. Water Vehicle");
        System.out.println("3. Exit");
        choice = scn.nextInt();
        
        if (choice == 1) {
        System.out.println("Choose kind of land vehicle: ");
        System.out.println("1. Car");
        System.out.println("2. Motorcycle");
        System.out.println("3. Truck");
        choice = scn.nextInt();
        
            if(choice == 1){
                System.out.print("Enter Car Type: ");
                String carType = scn.next();
                System.out.print("Enter Max Speed: ");
                double maxSpeed = scn.nextDouble();
                System.out.print("Enter Fuel Capacity: ");
                double fuelCapacity = scn.nextDouble();
                System.out.print("Enter has Tires: ");
                boolean hasTires = scn.nextBoolean();
                System.out.print("Enter Number of Wheels: ");
                int numWheels = scn.nextInt();
                System.out.print("Enter has Trunks: ");
                boolean hasTrunk = scn.nextBoolean();
                System.out.print("Enter Number of Doors: ");
                int numDoors = scn.nextInt();
                System.out.println("");
                Car myCar = new Car(carType, maxSpeed, fuelCapacity, hasTires, numWheels, hasTrunk, numDoors);
                myCar.display();
            
            }if(choice == 2){
                System.out.print("Enter Car Type: ");
                String carType = scn.next();
                System.out.print("Enter Max Speed: ");
                double maxSpeed = scn.nextDouble();
                System.out.print("Enter Fuel Capacity: ");
                double fuelCapacity = scn.nextDouble();
                System.out.print("Enter has Tires: ");
                boolean hasTires = scn.nextBoolean();
                System.out.print("Enter Number of Wheels: ");
                int numWheels = scn.nextInt();
                System.out.print("Has Handlebars True or False: ");
                boolean hasHandlebars = scn.nextBoolean();
                System.out.print("Has Trailer True or False: ");
                boolean isTwoWheeled = scn.nextBoolean();
                System.out.println("");
                Motorcycle myCar = new Motorcycle(carType, maxSpeed, fuelCapacity, hasTires, numWheels, hasHandlebars, isTwoWheeled);
                myCar.display();
            
            }if(choice == 3){
                System.out.print("Enter Car Type: ");
                String carType = scn.next();
                System.out.print("Enter Max Speed: ");
                double maxSpeed = scn.nextDouble();
                System.out.print("Enter Fuel Capacity: ");
                double fuelCapacity = scn.nextDouble();
                System.out.print("Enter has Tires: ");
                boolean hasTires = scn.nextBoolean();
                System.out.print("Enter Number of Wheels: ");
                int numWheels = scn.nextInt();
                System.out.print("Enter Load Capacity: ");
                double loadCapacity = scn.nextDouble();
                System.out.print("Has Trailer True or False: ");
                boolean hasTrailer = scn.nextBoolean();
                System.out.println("");
                Truck myCar = new Truck(carType, maxSpeed, fuelCapacity, hasTires, numWheels, loadCapacity, hasTrailer);
                myCar.display();
            
            }else {
                System.out.println("choose ");
            }
        
        }else if (choice == 2) {
            System.out.println("Choose kind of air vehicle: ");
            System.out.println("1. Airplane");
            System.out.println("2. Helicopter");
            choice = scn.nextInt();
            
            if (choice == 1) {
                Airplane airp = new Airplane("vehicleType", choice, choice, true, true, true, 0);
                airp.display();
                
            }else if (choice == 2) {
                Helicopter Heli = new Helicopter("vehicleType", choice, choice, true, true, true, true);
                Heli.display();
            }else {
                System.out.println("choose ");
            }
            
            
        }else if (choice == 3) {
            System.out.println("Choose kind of water vehicle: ");
            System.out.println("1. Boat");
            System.out.println("2. Ship");
            System.out.println("3. Submarine");
            choice = scn.nextInt();
            
            if (choice == 1) {
                Boat pambot = new Boat("vehicleType", choice, choice, true, true, true, true);
                pambot.display();
            
            }else if (choice == 2) {
                Ship ship = new Ship("vehicleType", choice, choice, true, true, true, true);
                ship.display();
            
            }else if (choice == 3) {
                Submarine subm = new Submarine("vehicleType", choice, choice, true, true, true, true);
                subm.display();
            }else {
                System.out.println("choose ");
            }
                
        
        }else if (choice == 4) {    
            System.out.println("Exit");
            
        }else {
            System.out.println("Choose another!");
        }
        
    }
    
}

