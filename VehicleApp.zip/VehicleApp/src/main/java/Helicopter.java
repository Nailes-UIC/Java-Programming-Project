public class Helicopter extends AirVehicle {
    private boolean hasRotorBlades;
    private boolean canHover;
    
    public Helicopter(String vehicleType, double maxSpeed, double fuelCapacity, boolean canFly, boolean hasWings, boolean hasRotorBlades, boolean canHover) {
        super(vehicleType, maxSpeed, fuelCapacity, hasWings, canFly);  // Call the constructor of Vehicle
        this.hasRotorBlades = hasRotorBlades;
        this.canHover = canHover;
    }
    
    public boolean hasRotorBlades() {
        return hasRotorBlades;
    }
    
    public boolean canHover() {
        return canHover;
    }
    
    @Override
    public void display() {
        super.display();  // Call the method from LandVehicle to display common info
        System.out.println("Has Rotor Blades: " + hasRotorBlades);
        System.out.println("Can Hover: " + canHover);
    }
}

