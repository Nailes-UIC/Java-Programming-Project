public class Boat extends WaterVehicle {
    private boolean isSailPowered;
    private boolean hasKeel;
    
    public Boat(String vehicleType, double maxSpeed, double fuelCapacity, boolean canFly, boolean hasWings, boolean isSailPowered, boolean hasKeel) {
        super(vehicleType, maxSpeed, fuelCapacity, hasWings, canFly);  // Call the constructor of Vehicle
        this.isSailPowered = isSailPowered;
        this.hasKeel = hasKeel;
    }
    
    public boolean isSailPowered() {
        return isSailPowered;
    }
    
    public boolean hasKeel() {
        return hasKeel;
    }
    
    @Override
    public void display() {
        super.display();  // Call the method from LandVehicle to display common info
        System.out.println("Is Sail Powered: " + isSailPowered);
        System.out.println("Has Keel: " + hasKeel);
    }
}
