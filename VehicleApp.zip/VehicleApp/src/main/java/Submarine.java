public class Submarine extends WaterVehicle {
    private boolean canSubmerge;
    private boolean hasTorpedoes;
    
    public Submarine(String vehicleType, double maxSpeed, double fuelCapacity, boolean canFly, boolean hasWings, boolean canSubmerge, boolean hasTorpedoes) {
        super(vehicleType, maxSpeed, fuelCapacity, hasWings, canFly);  // Call the constructor of Vehicle
        this.canSubmerge = canSubmerge;
        this.hasTorpedoes = hasTorpedoes;
    }
    
    public boolean canSubmerge() {
        return canSubmerge;
    }
    
    public boolean hasTorpedoes() {
        return hasTorpedoes;
    }
    
    @Override
    public void display() {
        super.display();  // Call the method from LandVehicle to display common info
        System.out.println("Can Submerge: " + canSubmerge);
        System.out.println("Has Torpedoes: " + hasTorpedoes);
    }
}

