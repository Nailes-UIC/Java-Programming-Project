public class AirVehicle extends Vehicle {
    private boolean canFly;
    private boolean hasWings;;
    
    // Constructor for LandVehicle
    public AirVehicle(String vehicleType, double maxSpeed, double fuelCapacity,boolean hasWings, boolean canFly) {
        super(vehicleType, maxSpeed, fuelCapacity);  // Call the constructor of the Vehicle class
        this.canFly = canFly;
        this.hasWings = hasWings;
    }

    // Method to check if the vehicle has tires
    public boolean canFly() {
        return canFly;
    }
    public boolean hasWings() {
        return hasWings;
    }

    public void display() {
        super.display();
        System.out.println("Can Fly: " + canFly);
        System.out.println("Has Wings: " + hasWings);
    }
}

